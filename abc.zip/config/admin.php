<?php

return [
	'jqadm' => [
	],
	'jsonadm' => [
	],
];
